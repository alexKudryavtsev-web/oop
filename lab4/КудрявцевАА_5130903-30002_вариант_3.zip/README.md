__Запуск:__

1) `cd lab`
2) `docker build -t lab .`
3) `docker run -it lab`