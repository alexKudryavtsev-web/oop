__Для запуска:__

1) `cd lab3`
2) `docker build -t lab3 .`
3) `docker run -it lab3`